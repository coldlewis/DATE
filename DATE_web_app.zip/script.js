
document.getElementById("addEvent").addEventListener("click", function() {
    const eventText = prompt("Inserisci il nome dell'evento:");
    if (eventText) {
        const eventDiv = document.createElement("div");
        eventDiv.textContent = eventText;
        document.getElementById("events").appendChild(eventDiv);
        localStorage.setItem("events", document.getElementById("events").innerHTML);
    }
});

window.onload = function() {
    const saved = localStorage.getItem("events");
    if (saved) {
        document.getElementById("events").innerHTML = saved;
    }
};
